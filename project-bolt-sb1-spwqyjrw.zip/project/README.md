# RealtyAI - Real Estate Chatbot Application

A simple real estate chatbot application with different user roles.

## Features

- ChatGPT-like interface for real estate questions
- Available on landing page for non-authenticated users
- Available on client dashboard for home buyers
- Realtor dashboard with prospect home buyers table
- Session-less authentication with server-side tokens
- Built with vanilla JavaScript, HTML, CSS, and Bootstrap

## Running the Application

1. Start the server:
   ```
   npm start
   ```

2. Open your browser to `http://localhost:3000`

## Login Credentials

For testing, use any username with password: `password`

- Client Role: Access to chat interface
- Realtor Role: Access to prospects table and can add new prospects

## Technology Stack

- Frontend: Plain HTML, CSS, Bootstrap 5, Vanilla JavaScript
- Backend: Plain Node.js (no framework)
- Database: PostgreSQL (credentials to be configured later)
- Authentication: Token-based (session-less)

## Notes

- Chat responses currently return "Server error" (placeholder for web service integration)
- Database connection is not yet configured
- No CRUD operations on prospects (add only)
