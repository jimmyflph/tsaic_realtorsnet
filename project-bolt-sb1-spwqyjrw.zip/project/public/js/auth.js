document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const role = document.getElementById('role').value;
  const errorMsg = document.getElementById('errorMsg');

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, role })
    });

    const data = await response.json();

    if (response.ok) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('username', username);
      localStorage.setItem('role', data.role);

      if (data.role === 'realtor') {
        window.location.href = '/realtor-home.html';
      } else {
        window.location.href = '/client-home.html';
      }
    } else {
      errorMsg.textContent = data.error;
      errorMsg.classList.remove('d-none');
    }
  } catch (error) {
    errorMsg.textContent = 'Login failed';
    errorMsg.classList.remove('d-none');
  }
});
