const token = localStorage.getItem('token');
const username = localStorage.getItem('username');
const role = localStorage.getItem('role');

if (!token || role !== 'client') {
  window.location.href = '/login.html';
}

document.getElementById('username').textContent = username;

function logout() {
  localStorage.clear();
  window.location.href = '/';
}
