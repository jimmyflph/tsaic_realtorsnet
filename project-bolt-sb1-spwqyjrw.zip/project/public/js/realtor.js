const token = localStorage.getItem('token');
const username = localStorage.getItem('username');
const role = localStorage.getItem('role');

if (!token || role !== 'realtor') {
  window.location.href = '/login.html';
}

document.getElementById('username').textContent = username;

function logout() {
  localStorage.clear();
  window.location.href = '/';
}

async function loadProspects() {
  try {
    const response = await fetch('/api/prospects', {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const prospects = await response.json();
    const tableBody = document.getElementById('prospectsTable');
    tableBody.innerHTML = '';

    prospects.forEach(prospect => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${prospect.name}</td>
        <td>${prospect.email}</td>
        <td>${prospect.phone}</td>
        <td>${prospect.budget}</td>
        <td>${prospect.location}</td>
      `;
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error('Failed to load prospects');
  }
}

async function addProspect() {
  const name = document.getElementById('prospectName').value;
  const email = document.getElementById('prospectEmail').value;
  const phone = document.getElementById('prospectPhone').value;
  const budget = document.getElementById('prospectBudget').value;
  const location = document.getElementById('prospectLocation').value;

  try {
    const response = await fetch('/api/prospects', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ name, email, phone, budget, location })
    });

    if (response.ok) {
      document.getElementById('prospectForm').reset();
      const modal = bootstrap.Modal.getInstance(document.getElementById('addProspectModal'));
      modal.hide();
      loadProspects();
    }
  } catch (error) {
    console.error('Failed to add prospect');
  }
}

loadProspects();
