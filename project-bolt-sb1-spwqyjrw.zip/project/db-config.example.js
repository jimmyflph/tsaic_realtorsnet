// PostgreSQL Database Configuration
// Copy this file to db-config.js and fill in your credentials

module.exports = {
  host: 'your-postgres-host',
  port: 5432,
  database: 'realtyai',
  user: 'your-username',
  password: 'your-password'
};
