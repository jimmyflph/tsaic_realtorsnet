const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = 3000;
const sessions = new Map();
const prospects = [];

const mimeTypes = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.json': 'application/json'
};

function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

function authenticate(req) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return null;
  const token = authHeader.replace('Bearer ', '');
  return sessions.get(token);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  if (pathname.startsWith('/api/')) {
    handleAPI(req, res, pathname);
  } else {
    handleStatic(req, res, pathname);
  }
});

function handleAPI(req, res, pathname) {
  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', () => {
    const data = body ? JSON.parse(body) : {};

    if (pathname === '/api/login' && req.method === 'POST') {
      const { username, password, role } = data;
      if (password === 'password') {
        const token = generateToken();
        sessions.set(token, { username, role });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ token, role }));
      } else {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid credentials' }));
      }
    } else if (pathname === '/api/chat' && req.method === 'POST') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Server error' }));
    } else if (pathname === '/api/prospects' && req.method === 'GET') {
      const user = authenticate(req);
      if (user && user.role === 'realtor') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(prospects));
      } else {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Forbidden' }));
      }
    } else if (pathname === '/api/prospects' && req.method === 'POST') {
      const user = authenticate(req);
      if (user && user.role === 'realtor') {
        prospects.push({ ...data, id: Date.now() });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
      } else {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Forbidden' }));
      }
    } else if (pathname === '/api/verify' && req.method === 'GET') {
      const user = authenticate(req);
      if (user) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(user));
      } else {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Unauthorized' }));
      }
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not found' }));
    }
  });
}

function handleStatic(req, res, pathname) {
  if (pathname === '/') pathname = '/index.html';

  const filePath = path.join(__dirname, 'public', pathname);
  const ext = path.extname(filePath);
  const contentType = mimeTypes[ext] || 'text/plain';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
}

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
